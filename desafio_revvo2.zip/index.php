<?php

// Autoload para carregar classes automaticamente
spl_autoload_register(function ($class) {
    $baseDir = __DIR__ . '/';
    $file = $baseDir . str_replace('\\', '/', $class) . '.php';
    if (file_exists($file)) {
        require $file;
    }
});

// Inclui o arquivo de roteamento
require 'Router.php';

// Captura a URL solicitada e a divide em partes
$url = isset($_GET['url']) ? $_GET['url'] : 'home';

// Cria uma instância do roteador e roteia a URL
$router = new Router();
$router->route($url);
