<?php ob_start(); ?>
<div class="single-course">
    <img src="<?= $course['image'] ?>" alt="<?= $course['title'] ?>">
    <h1><?= $course['title'] ?></h1>
    <p><?= $course['description'] ?></p>
    <a href="home.php" class="btn">Voltar</a>
</div>
<?php $content = ob_get_clean(); ?>
<?php include 'layout.php'; ?>
